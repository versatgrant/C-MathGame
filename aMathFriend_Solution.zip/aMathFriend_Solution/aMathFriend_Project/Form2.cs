﻿using System;
using System.Windows.Forms;
using System.Diagnostics;

namespace aMathFriend_Project
{
    public partial class frmApplications : Form
    {
        public String equation = "", answer = "", userAns = "", Score = "0";
        public String[] equArray = new String[2];
        public int scoreNum = 0, t = 0, timeLeft = 0, numCorrect = 0;
        Stopwatch stopWatch = new Stopwatch();

        public frmApplications()
        {
            InitializeComponent();
        }

        private void btnCheck_Click(object sender, EventArgs e)
        {
            int timeElapsed = time();
            checkAns(timeElapsed);
            startGame();
            txtUserAns.Clear();
        }

        private void txtUserAns_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (Char)13)
            {
                int timeElapsed = time();
                checkAns(timeElapsed);
                startGame();
                txtUserAns.Clear();
            }
        }

        private void frmApplications_Shown(object sender, EventArgs e)
        {
            stopWatch.Start();
            startGame();
        }

        public void startGame() {

            timeLeft = 10;
            equArray = generateEquation();
            equation = equArray[0];
            answer = equArray[1];
            label1.Text = equation;
            Score = scoreNum.ToString();
            lblScore.Text = "Score: " + Score;
            txtUserAns.Focus();
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (timeLeft > 0)
            {
                // Display the new time left
                // by updating the Time Left label.
                timeLeft = timeLeft - 1;
                lblTime.Text = timeLeft.ToString();
            }
        }

        public void checkAns(int t__) {
            userAns = txtUserAns.Text;
            if (answer == userAns)
            {
                score(t__);
                numCorrect++;
            }
            else {
                endGame();
            }

        }

        public void endGame() {
            DialogResult result = MessageBox.Show("You answered "+ numCorrect +" question(s) correctly.\nYour Score is: " + Score, "Game End", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            if (result == DialogResult.OK)
            {
                Application.Restart();
                
            }
        }



        public void score(int t_) {
            scoreNum += 10 + t_;
        }

        public int time() {
            t = (int) stopWatch.ElapsedMilliseconds / 1000 - t;
            t = 10 - t;
            if (t<0) {
                t = 0;
                stopWatch.Restart();
            }
            
            return t;
        }

        public String[] generateEquation()
        {
            String[] rand = new String[2];
            Char[] operators = { '+', '-', '*', '/' };
            int lOperand = 0, rOperand = 0;
            String equation, answer;
            int ans;
            Random r = new Random();
            Char operator_ = operators[r.Next(0, 4)];

            if (operator_ == operators[0] || operator_ == operators[1])
            {
                lOperand = r.Next(0, 101);
                rOperand = r.Next(0, 101);
                if (lOperand < rOperand && operator_ == operators[1])
                {
                    equation = rOperand.ToString() + " " + operator_.ToString() + " " + lOperand.ToString();
                    ans = rOperand - lOperand;
                    answer = ans.ToString();
                }
                else if (lOperand >= rOperand && operator_ == operators[1])
                {
                    equation = lOperand.ToString() + " " + operator_.ToString() + " " + rOperand.ToString();
                    ans = lOperand - rOperand;
                    answer = ans.ToString();
                }
                else
                {
                    equation = lOperand.ToString() + " " + operator_.ToString() + " " + rOperand.ToString();
                    ans = lOperand + rOperand;
                    answer = ans.ToString();
                }
            }
            else if (operator_ == operators[3])
            {
                rOperand = r.Next(2, 13);
                lOperand = r.Next(1, 51) * rOperand;
                equation = lOperand.ToString() + " " + operator_.ToString() + " " + rOperand.ToString();
                ans = lOperand / rOperand;
                answer = ans.ToString();
            }
            else
            {
                rOperand = r.Next(2, 13);
                lOperand = r.Next(1, 101);
                equation = lOperand.ToString() + " " + operator_.ToString() + " " + rOperand.ToString();
                ans = lOperand * rOperand;
                answer = ans.ToString();
            }

            rand[0] = equation;
            rand[1] = answer;
            return rand;
        }
    }
}